﻿using System;

namespace project_3
{
    class Program
    {
        static void Main(string[] args)
        {
            // 11. inch 단위를 입력 받아 cm 단위를 구하는 코드 작성
            Console.Write("숫자를 입력하세요 (inch 단위) : ");
            double number = double.Parse(Console.ReadLine());
            number *= 2.54;
            Console.WriteLine("cm로 변환한 결과 : " + number +"cm \n");
            //Console.WriteLine(number + "inch는 " + (number*2.54) +"cm이다. \n");


            // 12. kg 단위를 입력 받아 pound 단위를 구하는 코드 작성
            Console.Write("숫자를 입력하세요 (kg 단위) : ");
            double number2 = double.Parse(Console.ReadLine());
            number2 *= 2.20462262;
            Console.WriteLine("pound로 변환한 결과 : " + number2 + "pound \n");


            // 13. 원의 반지름을 입력받아 원의 둘레, 넓이를 구하는 코드 작성
            Console.Write("원의 반지름 입력 : ");
            double r = double.Parse(Console.ReadLine());
            double l = 2 * Math.PI * r;
            double area = Math.PI * Math.Pow(r, 2);
            Console.WriteLine("원의 둘레 : " + l + "\n원의 넓이 : " + area);
            //Console.WriteLine("원의 둘레 : " + (2 * 3.14 * r));
            //Console.WriteLine("원의 넓이 : " + (3.14 * r * r));
        }
    }
}
