﻿using System;

namespace project_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //입력 메소드 Console.ReadLine();
            //디폴트 자료형 문자열 string
            Console.Write("값을 입력 : ");
            string input1 = Console.ReadLine();
            Console.WriteLine(input1 + input1);           //문자열
            Console.WriteLine("input1 : " + input1);      //문자열


            //입력받은 문자열을 다른 자료형으로 변환하고 싶은 경우
            //자료형.Parse
            Console.Write("\n값을 입력 : ");
            int input2 = int.Parse(Console.ReadLine());
            Console.WriteLine(input2 + input2);
            Console.WriteLine("input2 : " + input2);


            //강제 형 변환
            //강제 형 변환시 데이터 손실이 발생할 수 있음
            var a = (int)10.0;
            var b = (double)10;


            //숫자형 문자열을 숫자로 변환
            string numStr = "12345";
            //int intNum = (int)numStr;
            /* string을 int로 강제 형변환 하는 것은 불가능
             * string은 class(설계도, 메모리 공간에 없음)  int는 구조체(메모리 공간에 있음)
             * 자료형.Parse 로 형 변환 가능함
             */
            Console.WriteLine(int.Parse("52"));
            Console.WriteLine(float.Parse("12.345"));
            Console.WriteLine(double.Parse("12.345"));
            Console.WriteLine(double.Parse("12.345").GetType());


            //문자형 문자열은 숫자형 자료형으로 형변환 할 수 없음
            //Console.WriteLine(int.Parse("ABC"));


            //기본 자료형을 문자열로 변환
            //.ToString()
            Console.WriteLine(52);
            Console.WriteLine((52).ToString());
            Console.WriteLine((12.345).ToString());
            Console.WriteLine((true).ToString());           //True
            Console.WriteLine(('a').ToString());            //a (아스키코드가 아닌 문자 a로 출력)
            Console.WriteLine(('a').ToString().GetType());  //System.String


            //실수 자료형의 소숫점 제거
            double number = 12.345;
            Console.WriteLine(number.ToString("0.0"));      //12.3
            Console.WriteLine(number.ToString("0.00"));     //12.34
            Console.WriteLine(number.ToString("0.000"));    //12.345


            //숫자가 자동으로 문자열로 변환될 때
            Console.WriteLine(52 + 52);         //104
            Console.WriteLine("52" + 273);      //52273
            Console.WriteLine(52 + "273");      //52273
            Console.WriteLine("52" + "273");    //52273


            int num = 12345;
            //string output = num + 'a';        //정수 + 문자 => int형
            string output = num + "a";          //정수 + 문자열 => 문자열

        }
    }
}
