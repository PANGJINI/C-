﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_4
{
    class Child : Parent
    {
        // base()
        // 반드시 부모생성자를 먼저 참조하라는 키워드
        public Child() : base()
        {
            Console.WriteLine("자식 생성자");
        }
    }
}
