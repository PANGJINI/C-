﻿using System;

namespace project_4
{
    class Program
    {
        static void Main(string[] args)
        {
            // 호출 순서 : 부모생성자 - 자식생성자
            // base() 키워드
            Child child = new Child();
        }
    }
}
