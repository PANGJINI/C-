﻿using System;
using System.Collections.Generic;

namespace project_2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            List<Dog> Dogs = new List<Dog>() { new Dog(), new Dog(), new Dog() };
            List<Cat> Cats = new List<Cat>() { new Cat(), new Cat(), new Cat() };

            foreach (var item in Dogs)
            {
                item.Eat();
                item.Sleep();
                item.Bark();
            }
            Console.WriteLine();

            foreach (var item in Cats)
            {
                item.Eat();
                item.Sleep();
                item.Meow();
            }
            */

            // 다형성
            // main의 코드 중복을 해결
            List<Animal> Animals = new List<Animal>()
            {
                new Dog(), new Cat(), new Dog(), new Cat(),
                new Dog(), new Cat(), new Dog(), new Cat()
            };

            foreach (var item in Animals)
            {
                item.Eat();
                item.Sleep();
                // ①일반적인 자료형 변환(1) Meow()가 출력되지 않음
                // ((Dog)item).Bark();
                // ((Cat)item).Meow();

                
                // ①일반적인 자료형 변환(2)
                // 자식 클래스의 메서드를 사용하기 위해서는
                // 자료형을 자식 클래스로 바꿔줘야 한다
                // is : 객체가 해당 형식에 해당하는지를 검사하여 그 결과를 bool로 변환
                if (item is Dog) { ((Dog)item).Bark(); }
                if (item is Cat) { ((Cat)item).Meow(); }
                Console.WriteLine();


                // ②as 키워드를 이용한 자료형 변환
                // as : 형식 변환 연산자와 같은 역할을 한다
                if (item is Dog) { (item as Dog).Bark(); }
                if (item is Cat) { (item as Cat).Meow(); }
                Console.WriteLine("----");
                
                // as 키워드를 사용하는 경우의 일반적인 형태
                var dog = item as Dog;
                if(dog != null) { dog.Bark(); }
                var cat = item as Cat;
                if(cat != null) { cat.Meow(); }

            }

           
        }
    }
}
