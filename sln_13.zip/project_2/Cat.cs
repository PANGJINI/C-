﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_2
{
    // 상속
    // 자식클래스 : 부모클래스
    // 클래스에서의 코드 중복을 해결한다.
    class Cat : Animal  
    {
        public void Meow()
        {
            Console.WriteLine("야옹");
        }
    }
}
