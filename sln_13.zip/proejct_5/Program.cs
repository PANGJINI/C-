﻿using System;

namespace proejct_5
{
    class Program
    {
        //⭐⭐시험 : 생성자 호출순서와 방법
        static void Main(string[] args)
        {
            Child childA = new Child();
            Child childB = new Child("string");

            /* 콘솔 출력 결과
             * Parent(int param)
             * Child() : base(10)
             * Parent(string param)
             * Child(string input) : base(input)
             */

        }
    }
}
