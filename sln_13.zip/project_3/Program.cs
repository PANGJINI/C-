﻿using System;

namespace project_3
{
    class Program
    {
        static void Main(string[] args)
        {
            // 상속을 했을 때 기본적인 호출 순서
            // 부모생성자 - 자식생성자
            Child child = new Child();
        }
    }
}
